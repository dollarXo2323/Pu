import React from 'react';

function Home() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Ласкаво просимо!</h1>
      <p>Це сайт Ukrainian Youth for Innovation.</p>
    </div>
  );
}

export default Home;